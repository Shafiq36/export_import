import React from "react";

const Import = () => {
  return <div>Import</div>;
};

export default Import;
